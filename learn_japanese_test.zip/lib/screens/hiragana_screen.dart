
import 'package:flutter/material.dart';
import '../widgets/word_detail.dart';

class HiraganaScreen extends StatefulWidget {
  const HiraganaScreen({super.key});

  @override
  State<HiraganaScreen> createState() => _HiraganaScreenState();
}

class _HiraganaScreenState extends State<HiraganaScreen> {
  String selectedLevel = 'JLPT 5';
  List<Map<String, String>> words = [
    {
      'hiragana': 'たべる',
      'kanji': '食べる',
      'romaji': 'taberu',
      'meaning': 'to eat',
      'sentence': 'わたしはりんごをたべる。',
      'sentenceRomaji': 'Watashi wa ringo o taberu.',
      'sentenceTranslation': 'I eat an apple.',
    },
    {
      'hiragana': 'のむ',
      'kanji': '飲む',
      'romaji': 'nomu',
      'meaning': 'to drink',
      'sentence': 'みずをのみます。',
      'sentenceRomaji': 'Mizu o nomimasu.',
      'sentenceTranslation': 'I drink water.',
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hiragana Words')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButton<String>(
              value: selectedLevel,
              items: ['JLPT 5'].map((String level) {
                return DropdownMenuItem<String>(
                  value: level,
                  child: Text(level),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedLevel = value!;
                });
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: words.length,
              itemBuilder: (context, index) {
                final word = words[index];
                return ListTile(
                  title: Text(word['hiragana']!, style: const TextStyle(fontSize: 20)),
                  subtitle: Text(word['meaning']!),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WordDetail(word: word),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
