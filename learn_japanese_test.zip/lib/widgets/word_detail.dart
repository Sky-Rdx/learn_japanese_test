
import 'package:flutter/material.dart';

class WordDetail extends StatelessWidget {
  final Map<String, String> word;

  const WordDetail({super.key, required this.word});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(word['hiragana']!)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(word['hiragana']!, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text('Kanji: ${word['kanji']}'),
            Text('Romaji: ${word['romaji']}'),
            Text('Meaning: ${word['meaning']}'),
            const SizedBox(height: 20),
            Text('Example:', style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(word['sentence']!),
            Text(word['sentenceRomaji']!),
            Text(word['sentenceTranslation']!),
          ],
        ),
      ),
    );
  }
}
