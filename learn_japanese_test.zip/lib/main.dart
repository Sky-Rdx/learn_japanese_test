
import 'package:flutter/material.dart';
import 'screens/hiragana_screen.dart';

void main() {
  runApp(const LearnJapaneseApp());
}

class LearnJapaneseApp extends StatelessWidget {
  const LearnJapaneseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Learn Japanese',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const HiraganaScreen(),
    Center(child: Text('Katakana coming soon')),
    Center(child: Text('Kanji coming soon')),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.text_fields), label: 'Hiragana'),
          BottomNavigationBarItem(icon: Icon(Icons.text_fields), label: 'Katakana'),
          BottomNavigationBarItem(icon: Icon(Icons.text_fields), label: 'Kanji'),
        ],
      ),
    );
  }
}
